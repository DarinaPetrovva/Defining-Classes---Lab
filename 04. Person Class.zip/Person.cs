﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace BankAccount
{
    class Person
    {
        private int age;
        private string name;
        List<BankAccount> accounts;
        public Person(string name, int age)
        {
            this.name = name;
            this.age = age;
            this.accounts = new List<BankAccount>();

        }
        public Person(string name, int age, List<BankAccount> accounts)
        {
            this.name = name;
            this.age = age;
            this.accounts = accounts;
        }
        public decimal GetBalance()
        {
            return accounts.Sum(x => x.Balance);
        }

    }
}
