﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BankAccount
{
    public class Startup
    {
        static void Main(string[] args)
        {
            var accounts = new List<BankAccount>();
            string input;
            while ((input = Console.ReadLine()) != "End")
            {
                var cmdArgs = input.Split();
                var command = cmdArgs[0];
                var id = int.Parse(cmdArgs[1]);
                BankAccount acc = accounts.FirstOrDefault(acc => acc.Id == id);
                switch (command)
                {
                    case "Create":
                        if (acc != null)
                        {
                            Console.WriteLine("Account already exists");
                        }
                        else
                        {
                            acc = new BankAccount();
                            acc.Id = id;
                            accounts.Add(acc);
                        }
                        break;
                    case "Deposit":
                        var amountToDeposit = decimal.Parse(cmdArgs[2]);
                        if (acc != null)
                        {
                            acc.Deposit(amountToDeposit);
                        }
                        else
                        {
                            Console.WriteLine("Account does not exist");
                        }
                        break;
                    case "Withdraw":
                        var amountToWithdraw = decimal.Parse(cmdArgs[2]);
                        if (acc != null)
                        {
                            acc.Withdraw(amountToWithdraw);
                        }
                        else
                        {
                            Console.WriteLine("Account does not exist");
                        }
                        break;
                    case "Print":
                        if (acc != null)
                        {
                            Console.WriteLine(acc.ToString());
                        }
                        else
                        {
                            Console.WriteLine("Account does not exist");
                        }
                        break;

                 
                }
            }

        }
    }
}
